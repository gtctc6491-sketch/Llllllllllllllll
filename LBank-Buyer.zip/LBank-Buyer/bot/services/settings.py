import json

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from database.models import BotSetting
from utils.defaults import DEFAULT_SETTINGS


class Settings:
    """In-memory cache of bot_settings table (single-process bot)."""

    def __init__(self) -> None:
        self.data: dict[str, str] = {}

    async def load(self, session: AsyncSession) -> None:
        rows = (await session.execute(select(BotSetting))).scalars().all()
        self.data = {r.key: r.value for r in rows}

    def get(self, key: str) -> str:
        return self.data.get(key, DEFAULT_SETTINGS.get(key, ""))

    def int(self, key: str) -> int:
        try:
            return int(self.get(key))
        except (TypeError, ValueError):
            return int(DEFAULT_SETTINGS.get(key, "0") or 0)

    def bool(self, key: str) -> bool:
        return self.get(key) in ("1", "true", "True", "yes")

    def emojis(self) -> dict:
        try:
            data = json.loads(self.get("custom_emojis") or "{}")
            return data if isinstance(data, dict) else {}
        except ValueError:
            return {}

    async def set(self, session: AsyncSession, key: str, value: str) -> None:
        row = await session.get(BotSetting, key)
        if row:
            row.value = value
        else:
            session.add(BotSetting(key=key, value=value))
        await session.flush()
        self.data[key] = value

    async def set_emojis(self, session: AsyncSession, emojis: dict) -> None:
        await self.set(session, "custom_emojis", json.dumps(emojis, ensure_ascii=False))


cfg = Settings()
