from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from bot.services.settings import cfg
from database.models import BotText, utcnow
from utils.defaults import DEFAULT_TEXTS
from utils.telegram_text import entities_from_json, render


class Texts:
    """Editable bot texts (cached). Values may carry Telegram entities (custom emoji, bold...)."""

    def __init__(self) -> None:
        self.data: dict[str, tuple[str, str]] = {}

    async def load(self, session: AsyncSession) -> None:
        rows = (await session.execute(select(BotText))).scalars().all()
        self.data = {r.key: (r.value, r.entities) for r in rows}

    def raw(self, key: str) -> tuple[str, str]:
        if key in self.data:
            return self.data[key]
        d = DEFAULT_TEXTS.get(key)
        return (d[2], "[]") if d else (key, "[]")

    def base_vars(self, user=None, **extra) -> dict:
        v: dict = {"sep": cfg.get("separator")}
        if user is not None:
            v["first_name"] = getattr(user, "first_name", "") or ""
            un = getattr(user, "username", None)
            v["username"] = f"@{un}" if un else "—"
            v["user_id"] = getattr(user, "id", "")
        v.update(extra)
        return v

    def render(self, key: str, user=None, **extra):
        value, ents_json = self.raw(key)
        return render(
            value, entities_from_json(ents_json), self.base_vars(user, **extra),
            cfg.emojis(), cfg.bool("premium_emoji"),
        )

    def plain(self, key: str, user=None, **extra) -> str:
        return self.render(key, user, **extra)[0]

    def button(self, key: str) -> str:
        value, _ = self.raw(key)
        return value.strip()[:60] or key

    async def set(self, session: AsyncSession, key: str, value: str, entities_json: str) -> None:
        row = await session.get(BotText, key)
        if row:
            row.value, row.entities, row.updated_at = value, entities_json, utcnow()
        else:
            session.add(BotText(key=key, value=value, entities=entities_json))
        await session.flush()
        self.data[key] = (value, entities_json)

    async def reset(self, session: AsyncSession, key: str) -> None:
        d = DEFAULT_TEXTS.get(key)
        if d:
            await self.set(session, key, d[2], "[]")


T = Texts()
