import asyncio
import logging

from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError, TelegramRetryAfter
from sqlalchemy import select

from bot.services.messaging import send_key_photo
from database.models import Broadcast, Gift, User, UserGift
from database.session import async_session

log = logging.getLogger(__name__)
_tasks: set[asyncio.Task] = set()


def spawn(coro) -> None:
    task = asyncio.create_task(coro)
    _tasks.add(task)
    task.add_done_callback(_tasks.discard)


async def safe_call(factory) -> bool:
    for _ in range(3):
        try:
            await factory()
            return True
        except TelegramRetryAfter as e:
            await asyncio.sleep(e.retry_after + 1)
        except (TelegramForbiddenError, TelegramBadRequest):
            return False
        except Exception as e:
            log.warning("send failed: %s", e)
            return False
    return False


async def run_broadcast(bot: Bot, broadcast_id: int, admin_chat: int, from_chat: int, msg_id: int) -> None:
    async with async_session() as s:
        ids = list((await s.execute(select(User.id).where(User.is_blocked.is_(False)))).scalars().all())
        b = await s.get(Broadcast, broadcast_id)
        b.total = len(ids)
        await s.commit()
    sent = failed = 0
    for uid in ids:
        ok = await safe_call(lambda uid=uid: bot.copy_message(uid, from_chat, msg_id))
        sent += ok
        failed += (not ok)
        await asyncio.sleep(0.05)
    async with async_session() as s:
        b = await s.get(Broadcast, broadcast_id)
        b.sent, b.failed, b.status = sent, failed, "done"
        await s.commit()
    await safe_call(lambda: bot.send_message(
        admin_chat, f"✅ پیام همگانی #{broadcast_id} تمام شد.\n📬 موفق: {sent}\n⚠️ ناموفق: {failed}\n👥 کل: {len(ids)}",
        parse_mode=None))


async def run_gift_to_all(bot: Bot, gift_id: int, admin_chat: int) -> None:
    async with async_session() as s:
        gift = await s.get(Gift, gift_id)
        ids = list((await s.execute(select(User.id).where(User.is_blocked.is_(False)))).scalars().all())
        name, desc, photo = gift.name, gift.description, gift.photo_id
    sent = failed = 0
    for uid in ids:
        async with async_session() as s:
            s.add(UserGift(user_id=uid, gift_id=gift_id, source="bulk"))
            await s.commit()
        ok = await safe_call(lambda uid=uid: send_key_photo(
            bot, uid, photo, "gift_received_admin", None, None, first_name="", gift_name=name, gift_desc=desc))
        sent += ok
        failed += (not ok)
        await asyncio.sleep(0.05)
    await safe_call(lambda: bot.send_message(
        admin_chat, f"✅ ارسال گروهی گیفت «{name}» تمام شد.\n📬 موفق: {sent}\n⚠️ ناموفق: {failed}", parse_mode=None))
