from typing import Callable

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from bot.services.texts import T


def btn(text: str, data: str | None = None, url: str | None = None) -> InlineKeyboardButton:
    if url:
        return InlineKeyboardButton(text=text, url=url)
    return InlineKeyboardButton(text=text, callback_data=data or "noop")


def ikb(rows: list[list[InlineKeyboardButton]]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[r for r in rows if r])


def tb(key: str) -> str:
    """Editable button label."""
    return T.button(key)


def pager_row(make_cb: Callable[[int], str], page: int, pages: int) -> list[InlineKeyboardButton]:
    if pages <= 1:
        return []
    row = []
    if page > 0:
        row.append(btn("◀️", make_cb(page - 1)))
    row.append(btn(f"📄 {page + 1}/{pages}", "noop"))
    if page < pages - 1:
        row.append(btn("▶️", make_cb(page + 1)))
    return row
