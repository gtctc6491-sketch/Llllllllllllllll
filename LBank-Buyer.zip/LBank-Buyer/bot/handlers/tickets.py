from aiogram import F, Router
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from bot.keyboards.common import btn, ikb, pager_row, tb
from bot.keyboards.user import cancel_only, home_row
from bot.services.messaging import answer_key, show
from bot.services.notify import admins_with, notify_admins, send_file
from bot.services.settings import cfg
from bot.states import TicketStates
from database.models import Ticket, TicketMessage, User, utcnow
from utils.helpers import (PAGE_SIZE, TICKET_EMOJI, TICKET_STATUS, clamp_page, fmt_dt, page_count, uname)

router = Router()
MAX_FILES = 5


def format_history(msgs: list[TicketMessage], viewer: str = "user", limit_chars: int = 3000) -> str:
    blocks = []
    for m in msgs:
        if m.sender_role == "admin":
            who = "👨‍💻 پشتیبان"
        else:
            who = "👤 شما" if viewer == "user" else "👤 کاربر"
        body = m.text or ""
        if m.file_id:
            body = (body + " " if body else "") + "📎(فایل)"
        blocks.append(f"{who} • {fmt_dt(m.created_at)}\n{body}")
    out = "\n\n".join(blocks)
    return out[-limit_chars:] if len(out) > limit_chars else out


async def ticket_messages(session: AsyncSession, tid: int, limit: int = 12) -> list[TicketMessage]:
    q = select(TicketMessage).where(TicketMessage.ticket_id == tid).order_by(TicketMessage.id.desc()).limit(limit)
    return list(reversed((await session.execute(q)).scalars().all()))


def ticket_kb(t: Ticket):
    rows = []
    if t.status != "closed":
        rows.append([btn(tb("btn_reply"), f"tk:reply:{t.id}"), btn(tb("btn_close_ticket"), f"tk:close:{t.id}")])
    rows.append([btn(tb("btn_back"), "tkp:0")])
    rows.append(home_row())
    return ikb(rows)


def attach_kb():
    return ikb([[btn(tb("btn_finish_ticket"), "tk:done")], [btn(tb("btn_cancel"), "tk:cancel")]])


@router.callback_query(F.data == "ticket")
async def ticket_menu(cb: CallbackQuery, state: FSMContext):
    await cb.answer()
    await state.clear()
    await show(cb, "ticket_menu", ikb([
        [btn(tb("btn_new_ticket"), "tk:new")], [btn(tb("btn_my_tickets"), "tkp:0")], home_row()]))


@router.callback_query(F.data == "tk:cancel")
async def tk_cancel(cb: CallbackQuery, state: FSMContext):
    await cb.answer()
    await state.clear()
    await show(cb, "ticket_menu", ikb([
        [btn(tb("btn_new_ticket"), "tk:new")], [btn(tb("btn_my_tickets"), "tkp:0")], home_row()]))


# ---------- create ----------
@router.callback_query(F.data == "tk:new")
async def tk_new(cb: CallbackQuery, state: FSMContext):
    await cb.answer()
    await state.clear()
    await state.set_state(TicketStates.title)
    await show(cb, "ticket_ask_title", cancel_only("tk:cancel"))


@router.message(TicketStates.title, F.text)
async def tk_title(message: Message, state: FSMContext):
    title = message.text.strip()
    if not (3 <= len(title) <= 150):
        await answer_key(message, "ticket_title_invalid", cancel_only("tk:cancel"))
        return
    await state.update_data(title=title)
    await state.set_state(TicketStates.description)
    await answer_key(message, "ticket_ask_desc", cancel_only("tk:cancel"))


@router.message(TicketStates.description, F.text)
async def tk_desc(message: Message, state: FSMContext):
    desc = message.text.strip()
    if not (1 <= len(desc) <= 3000):
        await answer_key(message, "ticket_desc_invalid", cancel_only("tk:cancel"))
        return
    await state.update_data(desc=desc, files=[])
    await state.set_state(TicketStates.attach)
    await answer_key(message, "ticket_ask_attach", attach_kb())


@router.message(StateFilter(TicketStates.title))
async def tk_title_bad(message: Message):
    await answer_key(message, "ticket_title_invalid", cancel_only("tk:cancel"))


@router.message(StateFilter(TicketStates.description))
async def tk_desc_bad(message: Message):
    await answer_key(message, "ticket_desc_invalid", cancel_only("tk:cancel"))


@router.message(TicketStates.attach, F.photo | F.document)
async def tk_attach(message: Message, state: FSMContext):
    data = await state.get_data()
    files = data.get("files", [])
    if len(files) < MAX_FILES:
        if message.photo:
            files.append({"t": "photo", "f": message.photo[-1].file_id})
        else:
            files.append({"t": "document", "f": message.document.file_id})
        await state.update_data(files=files)
    await answer_key(message, "ticket_attach_received", attach_kb())


@router.message(TicketStates.attach)
async def tk_attach_bad(message: Message):
    await answer_key(message, "ticket_ask_attach", attach_kb())


@router.callback_query(F.data == "tk:done", TicketStates.attach)
async def tk_done(cb: CallbackQuery, state: FSMContext, session: AsyncSession, bot, db_user: User):
    await cb.answer()
    data = await state.get_data()
    await state.clear()
    t = Ticket(user_id=cb.from_user.id, title=data["title"], description=data["desc"], status="waiting",
               created_at=utcnow(), updated_at=utcnow())
    session.add(t)
    await session.flush()
    session.add(TicketMessage(ticket_id=t.id, sender_role="user", sender_id=cb.from_user.id, text=data["desc"]))
    files = data.get("files", [])
    for f in files:
        session.add(TicketMessage(ticket_id=t.id, sender_role="user", sender_id=cb.from_user.id,
                                  file_id=f["f"], file_type=f["t"]))
    await session.flush()
    await show(cb, "ticket_created", ikb([[btn(tb("btn_view_ticket"), f"tk:view:{t.id}")], home_row()]),
               ticket_id=t.id, title=t.title)
    sep = cfg.get("separator")
    text = (f"🎫 تیکت جدید #{t.id}\n{sep}\n👤 {db_user.first_name} • {uname(db_user.username)} • {t.user_id}\n"
            f"📌 {t.title}\n📎 فایل‌ها: {len(files)}")
    await notify_admins(bot, session, "tickets", text, ikb([[btn("🔎 مشاهده و پاسخ", f"a:tk:{t.id}")]]))


# ---------- list / view ----------
@router.callback_query(F.data.startswith("tkp:"))
async def tk_list(cb: CallbackQuery, session: AsyncSession, state: FSMContext):
    await cb.answer()
    await state.clear()
    uid = cb.from_user.id
    page = int(cb.data.split(":")[1])
    total = await session.scalar(select(func.count(Ticket.id)).where(Ticket.user_id == uid)) or 0
    if total == 0:
        await show(cb, "ticket_list_empty", ikb([[btn(tb("btn_new_ticket"), "tk:new")], home_row()]))
        return
    pages = page_count(total)
    page = clamp_page(page, pages)
    rows_db = (await session.execute(select(Ticket).where(Ticket.user_id == uid).order_by(Ticket.id.desc())
                                     .offset(page * PAGE_SIZE).limit(PAGE_SIZE))).scalars().all()
    rows = [[btn(f"{TICKET_EMOJI.get(t.status, '•')} #{t.id} {t.title[:28]}", f"tk:view:{t.id}")] for t in rows_db]
    rows.append(pager_row(lambda p: f"tkp:{p}", page, pages))
    rows.append(home_row())
    await show(cb, "ticket_list", ikb(rows))


async def _own_ticket(session: AsyncSession, tid: int, uid: int) -> Ticket | None:
    t = await session.get(Ticket, tid)
    return t if t and t.user_id == uid else None


@router.callback_query(F.data.startswith("tk:view:"))
async def tk_view(cb: CallbackQuery, session: AsyncSession, bot, state: FSMContext):
    await state.clear()
    t = await _own_ticket(session, int(cb.data.split(":")[2]), cb.from_user.id)
    if not t:
        await cb.answer()
        await show(cb, "ticket_not_found", ikb([home_row()]))
        return
    await cb.answer()
    msgs = await ticket_messages(session, t.id)
    await show(cb, "ticket_view", ticket_kb(t), ticket_id=t.id, title=t.title,
               status=TICKET_STATUS.get(t.status, t.status), history=format_history(msgs, "user"))
    for m in [x for x in msgs if x.file_id and x.sender_role == "admin"][-3:]:
        try:
            await send_file(bot, cb.from_user.id, m.file_type, m.file_id, caption=f"📎 تیکت #{t.id}")
        except Exception:
            pass


@router.callback_query(F.data.startswith("tk:close:"))
async def tk_close(cb: CallbackQuery, session: AsyncSession):
    t = await _own_ticket(session, int(cb.data.split(":")[2]), cb.from_user.id)
    if not t:
        await cb.answer()
        await show(cb, "ticket_not_found", ikb([home_row()]))
        return
    t.status, t.updated_at = "closed", utcnow()
    await cb.answer()
    await show(cb, "ticket_closed", ikb([[btn(tb("btn_my_tickets"), "tkp:0")], home_row()]),
               ticket_id=t.id, title=t.title)


# ---------- user reply ----------
@router.callback_query(F.data.startswith("tk:reply:"))
async def tk_reply_start(cb: CallbackQuery, session: AsyncSession, state: FSMContext):
    t = await _own_ticket(session, int(cb.data.split(":")[2]), cb.from_user.id)
    if not t:
        await cb.answer()
        await show(cb, "ticket_not_found", ikb([home_row()]))
        return
    await cb.answer()
    if t.status == "closed":
        await show(cb, "ticket_already_closed", ikb([[btn(tb("btn_back"), "tkp:0")], home_row()]))
        return
    await state.clear()
    await state.set_state(TicketStates.reply)
    await state.update_data(tid=t.id)
    await show(cb, "ticket_ask_reply", cancel_only(f"tk:view:{t.id}"))


@router.message(TicketStates.reply, F.text | F.photo | F.document)
async def tk_reply(message: Message, state: FSMContext, session: AsyncSession, bot, db_user: User):
    data = await state.get_data()
    t = await _own_ticket(session, data.get("tid", 0), message.from_user.id)
    await state.clear()
    if not t or t.status == "closed":
        await answer_key(message, "ticket_already_closed", ikb([home_row()]))
        return
    text = message.text or message.caption
    file_id = file_type = None
    if message.photo:
        file_id, file_type = message.photo[-1].file_id, "photo"
    elif message.document:
        file_id, file_type = message.document.file_id, "document"
    session.add(TicketMessage(ticket_id=t.id, sender_role="user", sender_id=message.from_user.id,
                              text=text, file_id=file_id, file_type=file_type))
    t.status, t.updated_at = "waiting", utcnow()
    await session.flush()
    await answer_key(message, "ticket_reply_sent", ikb([[btn(tb("btn_view_ticket"), f"tk:view:{t.id}")], home_row()]),
                     ticket_id=t.id)
    sep = cfg.get("separator")
    note = f"💬 پیام جدید در تیکت #{t.id}\n{sep}\n👤 {db_user.first_name} • {uname(db_user.username)}\n📌 {t.title}\n{(text or '📎 فایل')[:500]}"
    await notify_admins(bot, session, "tickets", note, ikb([[btn("🔎 مشاهده و پاسخ", f"a:tk:{t.id}")]]))
    if file_id:
        for admin in await admins_with(session, "tickets"):
            try:
                await send_file(bot, admin.user_id, file_type, file_id, caption=f"📎 تیکت #{t.id}")
            except Exception:
                pass


@router.message(TicketStates.reply)
async def tk_reply_bad(message: Message):
    await answer_key(message, "ticket_ask_reply", None)
