from aiogram import F, Router
from aiogram.types import CallbackQuery
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from bot.keyboards.common import btn, ikb, pager_row, tb
from bot.keyboards.user import home_row
from bot.services.messaging import show, show_photo
from bot.services.texts import T
from database.models import Gift, UserGift
from utils.helpers import PAGE_SIZE, clamp_page, page_count

router = Router()


@router.callback_query(F.data.startswith("giftp:") | (F.data == "gift"))
async def gift_list(cb: CallbackQuery, session: AsyncSession):
    await cb.answer()
    page = int(cb.data.split(":")[1]) if ":" in cb.data else 0
    cond = (Gift.is_active.is_(True), Gift.is_deleted.is_(False))
    total = await session.scalar(select(func.count(Gift.id)).where(*cond)) or 0
    if total == 0:
        await show(cb, "gift_empty", ikb([home_row()]))
        return
    pages = page_count(total)
    page = clamp_page(page, pages)
    gifts = (await session.execute(select(Gift).where(*cond).order_by(Gift.id.desc())
                                   .offset(page * PAGE_SIZE).limit(PAGE_SIZE))).scalars().all()
    rows = [[btn(f"{'🎁' if g.stock > 0 else '❌'} {g.name}", f"gift:view:{g.id}")] for g in gifts]
    rows.append(pager_row(lambda p: f"giftp:{p}", page, pages))
    rows.append(home_row())
    await show(cb, "gift_list", ikb(rows))


@router.callback_query(F.data.startswith("gift:view:"))
async def gift_view(cb: CallbackQuery, session: AsyncSession):
    await cb.answer()
    g = await session.get(Gift, int(cb.data.split(":")[2]))
    if not g or not g.is_active or g.is_deleted:
        await show(cb, "gift_empty", ikb([home_row()]))
        return
    rows = []
    if g.stock > 0:
        rows.append([btn(tb("btn_claim_gift"), f"gift:claim:{g.id}")])
    rows.append([btn(tb("btn_back"), "gift")])
    text, ents = T.render("gift_detail", cb.from_user, gift_name=g.name, gift_desc=g.description or "—",
                          gift_stock=g.stock)
    if g.photo_id:
        await show_photo(cb, g.photo_id, text, ikb(rows), ents)
    else:
        from bot.services.messaging import show_text
        await show_text(cb, text, ents, ikb(rows))


@router.callback_query(F.data.startswith("gift:claim:"))
async def gift_claim(cb: CallbackQuery, session: AsyncSession):
    gid = int(cb.data.split(":")[2])
    back = ikb([[btn(tb("btn_back"), "gift")], home_row()])
    g = (await session.execute(select(Gift).where(Gift.id == gid).with_for_update())).scalar_one_or_none()
    if not g or not g.is_active or g.is_deleted:
        await cb.answer()
        await show(cb, "gift_empty", back)
        return
    if g.stock <= 0:
        await cb.answer()
        await show(cb, "gift_out_of_stock", back, gift_name=g.name)
        return
    if g.per_user_limit > 0:
        got = await session.scalar(select(func.count(UserGift.id)).where(
            UserGift.user_id == cb.from_user.id, UserGift.gift_id == gid)) or 0
        if got >= g.per_user_limit:
            await cb.answer()
            await show(cb, "gift_limit_reached", back, gift_name=g.name)
            return
    g.stock -= 1
    session.add(UserGift(user_id=cb.from_user.id, gift_id=gid, source="claim"))
    await session.flush()
    await cb.answer()
    await show(cb, "gift_claimed", back, gift_name=g.name)
