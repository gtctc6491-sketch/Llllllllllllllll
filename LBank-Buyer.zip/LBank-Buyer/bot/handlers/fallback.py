from aiogram import Router
from aiogram.filters import StateFilter
from aiogram.types import Message

from bot.keyboards.user import main_menu
from bot.services.messaging import answer_key

router = Router()


@router.message(StateFilter(None))
async def any_message(message: Message, is_admin: bool):
    await answer_key(message, "menu_title", main_menu(is_admin))
