from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from config.settings import DATABASE_URL
from database.models import Base

engine = create_async_engine(DATABASE_URL, pool_pre_ping=True)
async_session = async_sessionmaker(engine, expire_on_commit=False)


async def init_db() -> None:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
